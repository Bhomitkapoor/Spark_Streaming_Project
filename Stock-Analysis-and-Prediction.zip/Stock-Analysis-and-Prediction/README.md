# Stock-Analysis-and-Prediction

This blog of mine uses Apache Spark SQL and DataFrames to query, compare and explore Yahoo Fin, Google Fin and fundamental metrics from Annual SEC 10K fillings for companies stock prices for the past 5 years. Can these Stocks variations and Human Sentiments on Twitter show some amazing pattern depicting there correlation over the past decade? Lets see [Yahoo!Spark](http://kocharshaivi19.github.io/Stock-Analysis-and-Prediction/Yahoo!Spark) :)

![](screenshot/stockviz.gif)
